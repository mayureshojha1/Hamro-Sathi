import React from 'react'

function LoginRegister() {
  return (
    <div>LoginRegister</div>
  )
}

export default LoginRegister