import ShowcaseCarousel from './shared/ShowcaseCarousel';

function Showcase({ slides }) {
	return <ShowcaseCarousel slides={slides} />;
}

export default Showcase;
